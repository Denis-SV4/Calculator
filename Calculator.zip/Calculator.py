from tkinter import *
from tkinter import ttk
import calculate_tools

# Настройка окна
root = Tk()
root.geometry('350x470')
root.iconbitmap(default='icon.ico')
root.title('Calculator by Denis Svechin')

# Глобальная настройка сетки для root (чтобы все элементы тянулись)
root.rowconfigure(0, weight=1)  # Фрейм с результатом
root.rowconfigure(1, weight=3)  # Фрейм с кнопками
root.columnconfigure(0, weight=1)

# Фрейм для вывода результата
result_frame = ttk.Frame(root, borderwidth=1, padding=[10, 10])
result_frame.grid(row=0, column=0, sticky="nsew")  # Заполняет всё пространство в row 0

# Поле вывода
result_label = ttk.Label(result_frame, font=('Ariel', 20), anchor="e", justify="right", relief=SOLID)
result_label.pack(fill="both", expand=True, padx=5, pady=5)  # Заполняет фрейм

# Фрейм для кнопок
button_frame = ttk.Frame(root, borderwidth=1)
button_frame.grid(row=1, column=0, sticky="nsew")  # Заполняет всё пространство в row 1

# Настройка сетки внутри button_frame
for i in range(5):
    button_frame.rowconfigure(i, weight=1)
for i in range(4):
    button_frame.columnconfigure(i, weight=1)

# Функция для создания кнопки, которая тянется при изменении окна
def create_button(text, row, col, command):
    btn = ttk.Button(button_frame, text=text, command=lambda: command(result_label))
    btn.grid(row=row, column=col, sticky="nsew", padx=1, pady=1)  # Кнопки заполняют ячейки

# Кнопки (подключаем функции из calculate_tools)
create_button("x²", 0, 0, calculate_tools.square_number)
create_button("√x", 0, 1, calculate_tools.square_root)
create_button("C", 0, 2, calculate_tools.clear_result)
create_button("⌫", 0, 3, calculate_tools.delete_last)

create_button("1", 1, 0, lambda lbl: calculate_tools.on_button_click(lbl, "1"))
create_button("2", 1, 1, lambda lbl: calculate_tools.on_button_click(lbl, "2"))
create_button("3", 1, 2, lambda lbl: calculate_tools.on_button_click(lbl, "3"))
create_button("+", 1, 3, lambda lbl: calculate_tools.on_button_click(lbl, "+"))

create_button("4", 2, 0, lambda lbl: calculate_tools.on_button_click(lbl, "4"))
create_button("5", 2, 1, lambda lbl: calculate_tools.on_button_click(lbl, "5"))
create_button("6", 2, 2, lambda lbl: calculate_tools.on_button_click(lbl, "6"))
create_button("-", 2, 3, lambda lbl: calculate_tools.on_button_click(lbl, "-"))

create_button("7", 3, 0, lambda lbl: calculate_tools.on_button_click(lbl, "7"))
create_button("8", 3, 1, lambda lbl: calculate_tools.on_button_click(lbl, "8"))
create_button("9", 3, 2, lambda lbl: calculate_tools.on_button_click(lbl, "9"))
create_button("×", 3, 3, lambda lbl: calculate_tools.on_button_click(lbl, "×"))

create_button(".", 4, 0, lambda lbl: calculate_tools.on_button_click(lbl, "."))
create_button("0", 4, 1, lambda lbl: calculate_tools.on_button_click(lbl, "0"))
create_button("=", 4, 2, calculate_tools.evaluate_expression)
create_button("÷", 4, 3, lambda lbl: calculate_tools.on_button_click(lbl, "÷"))

# Основной цикл
root.mainloop()