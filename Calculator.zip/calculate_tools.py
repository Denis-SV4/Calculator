MAX_LENGTH = 20  # Ограничение длины ввода

def on_button_click(result_label, digit):
    current_text = result_label.cget("text")
    
    if len(current_text) < MAX_LENGTH:
        new_text = current_text + str(digit)
        result_label.config(text=new_text)

def clear_result(result_label):
    result_label.config(text="", font=("Ariel", 20))

def delete_last(result_label):
    current_text = result_label.cget("text")
    if current_text:
        new_text = current_text[:-1]
        result_label.config(text=new_text)

def evaluate_expression(result_label):
    try:
        current_text = result_label.cget("text")
        if current_text:
            result = eval(current_text.replace("×", "*").replace("÷", "/"))  # Заменяем символы
            result_label.config(text=str(result), font=("Ariel", 20))
    except Exception:
        result_label.config(text="Ошибка", font=("Ariel", 20))

def reverse_sign(result_label):
    current_text = result_label.cget("text")
    if current_text:
        if current_text[0] == "-":
            result_label.config(text=current_text[1:])
        else:
            result_label.config(text="-" + current_text)

def square_number(result_label):
    try:
        current_text = result_label.cget("text")
        if current_text:
            result = float(current_text) ** 2
            result_label.config(text=str(result))
    except Exception:
        result_label.config(text="Ошибка")

def square_root(result_label):
    try:
        current_text = result_label.cget("text")
        if current_text:
            result = float(current_text) ** 0.5
            result_label.config(text=str(result))
    except Exception:
        result_label.config(text="Ошибка")